const form = document.querySelector('.signupForm');
const message = form.querySelector('.message');

form.addEventListener('submit', e => {
  e.preventDefault();

  const username = form.elements['username'].value.trim();
  const email = form.elements['email'].value.trim();
  const sifre = form.elements['sifre'].value;

  const usernamePattern = /^[a-z]{6,10}$/;

  // Email kontrolü
  if (!(email.length >= 8 && email.includes("@") && email.includes("."))) {
    message.textContent = " Geçersiz e-posta: En az 8 karakter olmalı, '@' ve '.' içermelidir.";
    message.style.color = "red";
    return;
  }

  // Kullanıcı adı kontrolü
  if (!usernamePattern.test(username)) {
    message.textContent = " Başarısız: Kullanıcı adı sadece küçük harflerden oluşmalı ve 6-10 karakter arası olmalı.";
    message.style.color = "red";
    return;
  }

  // Şifre kontrolü
  const büyükHarf = /[A-Z]/.test(sifre);
  const kücükHarf = /[a-z]/.test(sifre);
  const sayi = /[0-9]/.test(sifre);
  const uzunluk = sifre.length >= 6;

  if (!(büyükHarf && kücükHarf && sayi && uzunluk)) {
    message.textContent = " Şifre geçersiz: En az 6 karakter, 1 büyük harf, 1 küçük harf ve 1 sayı içermeli.";
    message.style.color = "red";
    return;
  }

  message.textContent = " Başarılı kayıt!";
  message.style.color = "green";
});
